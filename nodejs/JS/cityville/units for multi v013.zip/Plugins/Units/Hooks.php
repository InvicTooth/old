<?php
function Produce_Units($bot)
{
	// scripted by KPD
	if ($bot->firstrun) {
		return;
	}
	$bot->SendMsg('Produce units initializing...');
	$bot->SendMsg('');
	$bot->ReloadConfig();
	
	
	$xmlsOb = new xmlsOb();
	$xmlsOb->GenerateData();
	$units = array();
	foreach ($xmlsOb->gsXML->items->item as $obj){
		if( $obj['type'] == 'Buildable' &&
			($obj['subtype'] == 'air' || $obj['subtype'] == 'army' || $obj['subtype'] == 'navy')) {
			$code = (string)$obj['code'];
			$tempunit['code'] = $code; // $key
			$tempunit['name'] = $obj['name'];
			$tempunit['ingamename'] = $xmlsOb->GetFnamefromCode($code);
			$tempunit['have'] = 0;
			$tempunit['want'] = 0;
			$tempunit['count'] = 0;
			$units[$code] = $tempunit;
		}
	}
	
	$data = $bot->ld->GetPlSettings("Units");
	$unitcounts = (array)$data->wants;
	foreach ($unitcounts as $key => $unitcount){
		$units[$key]['want'] = $unitcount;
	}
	
	foreach ($bot->inventory as $key => $have){
		if( $units[$key]['name'] != ''){
			$units[$key]['have'] = $have;
		}
	}
	
	$flag = 0;
	foreach($units as $key => $unit) {
		if ($unit['count'] > 0) $bot->sendMsg($key.', '.$unit['ingamename'].' : '.$unit['count']);
		// $count = $units[$key]['want'] - $units[$key]['have'];
		$count = $units[$key]['want'];
		$units[$key]['count'] = $count;
		if ($count > 0) $flag += $count;
	}
	
	if ((int)$data->produce != 1) {
		return;
	}
	
	if ($flag < 1){
		$bot->SendMsg('No units selected to produce.');
		$bot->SendMsg('');
		return;
	}

	foreach ($bot->fobjects as $obj) {
		if (($obj["itemName"] == 'Barracks 01') || ($obj["itemName"] == 'Barracks 02') || ($obj["itemName"] == 'Barracks 03')
			|| ($obj["itemName"] == 'Hangar 01') || ($obj["itemName"] == 'Hangar 02') || ($obj["itemName"] == 'Hangar 03')
			|| ($obj["itemName"] == 'Drydocks 01') || ($obj["itemName"] == 'Drydocks 02') || ($obj["itemName"] == 'Drydocks 03'))
		{
			if ($obj["state"] == 10) {
				setState($bot,$obj,Null);
				$bot->SendMsg('Clearing out '.$obj["itemName"] . ' ID : ' . $obj['id']);
				sleep(0.5);
			}
			if ($obj["state"] == 8 || $obj["state"] == 10){
				foreach($units as $key => $unit) {
					if ($unit['count'] > 0) {
						setState($bot,$obj,$key);
						$bot->SendMsg('Success building '.$unit['ingamename'].' : '.$obj["itemName"] . ' ID : ' . $obj['id']);
						$units[$key]['count']--;
						$flag--;
						break;
					}
				}
			}
			if ($flag < 1) {
				$bot->SendMsg('Nothing else to do.');
				return;
			}
		}

		if (isset($bot->error_msg)) {
			$bot->ReloadConfig();
			break;
		}
	}

	$bot->SendMsg('');
	$bot->SendMsg('Done building...');

}
$this->AddHook('produce_units', 'Produce_Units');

// ==============================================================================
function setState($bot,$obj,$itemcode) // produce locked units
{
    unset($bot->error_msg);
    $amf = new AMFObject("");
    $amf->_bodys[0] = new MessageBody();
    $amf->_bodys[0]->_value[0] = $bot->GetAmfHeader();

    $amf->_bodys[0]->targetURI = 'BaseService.dispatchBatch';
    $amf->_bodys[0]->responseURI = '';
    $amf->_bodys[0]->_value[2] = 0;
	
	$amf->_bodys[0]->_value[1][0]['sequence'] = $bot->GetSequense();
    $amf->_bodys[0]->_value[1][0]['functionName'] = "WorldService.performAction";
    $amf->_bodys[0]->_value[1][0]['params'][0] = "setState";
    $amf->_bodys[0]->_value[1][0]['params'][1] = $obj;
	$amf->_bodys[0]->_value[1][0]['params'][2][0]['referenceItem'] = $itemcode;
	$amf->_bodys[0]->_value[1][0]['params'][1]['ch'] = $bot->ch($amf->_bodys[0]->_value[1][0]['params'][1]);
	$amf->_bodys[0]->_value[1][0]['params'][2][0]['ch'] = $bot->ch($amf->_bodys[0]->_value[1][0]['params'][2][0]);
	
    $serializer = new AMFSerializer();
    $result = $serializer->serialize($amf);
    return $bot->SendRequest($result);
} 


	
?>
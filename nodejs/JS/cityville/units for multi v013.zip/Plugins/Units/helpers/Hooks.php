<?php
function MaterialsSearch($bot)
{
	// scripted by KPD
	if ($bot->firstrun) {
		return;
	}
	$bot->SendMsg('Searching for material initializing...');
	$bot->SendMsg('');
	$bot->ReloadConfig();
	$data = $bot->ld->GetPlSettings("Market");
	$started = (int)$data->buystart;
	if ((int)$data->buystart != 1) {
		return;
	}

	$found = false;
	$itemlist = array (1=>"oil",2=>"wood",3=>"aluminum",4=>"copper",5=>"gold",6=>"iron",7=>"uranium");
	$boughtlist = array (1=>0,2=>0,3=>0,4=>0,5=>0,6=>0,7=>0);
	$inventlist = array (1=>(int)$data->oilcount,2=>(int)$data->woodcount,3=>(int)$data->aluminumcount,4=>(int)$data->coppercount,5=>(int)$data->goldcount,6=>(int)$data->ironcount,7=>(int)$data->uraniumcount);
	$neighbors = ($bot->ld->GetSelect('SELECT value FROM neighborslist'));
	foreach($neighbors as $neighbor)
	{
		$tmp=unserialize($neighbor['value']);
		$hostid=$tmp['uid'];
		$visitname=$tmp['worldName'];
		//$bot->SendMsg($hostid.' - '.$visitname);
		$amf = new AMFObject($bot->LoadWorld($hostid, $visitname));
		if (isset($bot->error_msg)) 
		{ 
			$bot->SendMsg("Error getting into ".$visitname." market.");
			break;
		}
		$deserializer = new AMFDeserializer($amf->rawData);
		$deserializer->deserialize($amf);
		$bod = new MessageBody();
		$bod = $amf->_bodys[0];
		foreach ($bod->_value['data'][0]['data']['world']['objects'] as $obj)
		{
			if (($obj['itemName']=="Market") && ($obj['type']=="resource"))
			{
				$found = true;
				//$bot->SendMsg("Found Market with ID: ".$obj['id']." at ".$obj['position']);
				$amf1 = new AMFObject(list_market($bot,$hostid, $obj['id'],$obj['position']));
				$deserializer = new AMFDeserializer($amf1->rawData);
				$deserializer->deserialize($amf1);
				$bod1 = new MessageBody();
				$bod1 = $amf1->_bodys[0];
				foreach ($bod1->_value['data'][0]['data'] as $obj1)
				{
					if ($obj1['units']>0)
					{
						$bot->SendMsg($visitname. " - Found ".$obj1['units']." ".$itemlist[$obj1['item']]);
						if (($obj1['id']==$obj['id']) && ($inventlist[$obj1['item']] > 0 ))
						{

							if ($inventlist[$obj1['item']] > $obj1['units'])
							{
								buy_item($bot,$hostid,$obj['id'],$obj['position'],$obj1['item'],$obj1['units']);
								$bot->SendMsg("   >>> Bought ".$obj1['units']." ".$itemlist[$obj1['item']]);
								$boughtlist[$obj1['item']]=$boughtlist[$obj1['item']]+$obj1['units'];
								$inventlist[$obj1['item']] = $inventlist[$obj1['item']] - $obj1['units'];
							} else {
								buy_item($bot,$hostid,$obj['id'],$obj['position'],$obj1['item'],$inventlist[$obj1['item']]);
								$bot->SendMsg("   >>> Bought ".$inventlist[$obj1['item']]." ".$itemlist[$obj1['item']]);
								$boughtlist[$obj1['item']]=$boughtlist[$obj1['item']]+$inventlist[$obj1['item']];
								$inventlist[$obj1['item']] = 0;
							}
						}
					}
				}
            }
		}
		if ($found == false){
			$bot->SendMsg("No market found for user: ".$visitname);
		}
		$found = false;
	}
	$data->buystart = 0;
	$data->oilcount = (int)$inventlist[1];
	$data->woodcount = (int)$inventlist[2];
	$data->goldcount = (int)$inventlist[5];
	$data->coppercount = (int)$inventlist[4];
	$data->ironcount = (int)$inventlist[6];
	$data->aluminumcount = (int)$inventlist[3];
	$data->uraniumcount = (int)$inventlist[7];
	$bot->ld->ExecQuery("update plugin_settings set value='" . serialize($data) . "' where plname='Market'");
	for ($i = 1;$i < 8;$i++){
		if ($boughtlist[$i] > 0){
			$bot->SendMsg('You bought total of '.$boughtlist[$i].' '.$itemlist[$i]);
		}
	}
	$bot->SendMsg('Done buying...');
}
$this->AddHook('search_materials', 'MaterialsSearch');


// ==============================================================================
    function buy_item($bot,$hostid,$marketid,$marketpos,$itemcode,$amount) // Added by kpd for buying neighbor's market
    {
        unset($bot->error_msg);
        $amf = new AMFObject("");
        $amf->_bodys[0] = new MessageBody();
        $amf->_bodys[0]->_value[0] = $bot->GetAmfHeader();

        $amf->_bodys[0]->targetURI = 'BaseService.dispatchBatch';
        $amf->_bodys[0]->responseURI = '';
        $amf->_bodys[0]->_value[2] = 0;

        $amf->_bodys[0]->_value[1][0]['sequence'] = $bot->GetSequense();
        $amf->_bodys[0]->_value[1][0]['functionName'] = "WorldService.performAction";

        $amf->_bodys[0]->_value[1][0]['params'][0] = 'buy';
		$amf->_bodys[0]->_value[1][0]['params'][1] = array();
	    $amf->_bodys[0]->_value[1][0]['params'][1]['itemName'] = 'Market';
		$amf->_bodys[0]->_value[1][0]['params'][1]['id'] = $marketid;
		$amf->_bodys[0]->_value[1][0]['params'][1]['position'] = $marketpos;
		$amf->_bodys[0]->_value[1][0]['params'][1]['ch'] = $bot->ch($amf->_bodys[0]->_value[1][0]['params'][1]);
		
		$amf->_bodys[0]->_value[1][0]['params'][2][0] = array();
		$amf->_bodys[0]->_value[1][0]['params'][2][0]['item'] = $itemcode;
		$amf->_bodys[0]->_value[1][0]['params'][2][0]['hostId'] = $hostid;
		$amf->_bodys[0]->_value[1][0]['params'][2][0]['units'] = $amount;
		//$amf->_bodys[0]->_value[1][0]['params'][1]['price'] = $price;
		$amf->_bodys[0]->_value[1][0]['params'][2][0]['ch'] = $bot->ch($amf->_bodys[0]->_value[1][0]['params'][2][0]);
		
        $serializer = new AMFSerializer();
        $result = $serializer->serialize($amf);
        return $bot->SendRequest($result);
    } 

	// ==============================================================================
    function list_market($bot,$neighid,$marketid,$marketpos) // Added by kpd
    {
        unset($bot->error_msg);
        $amf = new AMFObject("");
        $amf->_bodys[0] = new MessageBody();
        $amf->_bodys[0]->_value[0] = $bot->GetAmfHeader();

        $amf->_bodys[0]->targetURI = 'BaseService.dispatchBatch';
        $amf->_bodys[0]->responseURI = '';
        $amf->_bodys[0]->_value[2] = 0;

        $amf->_bodys[0]->_value[1][0]['sequence'] = $bot->GetSequense();
		//$amf->_bodys[0]->_value[1][0]['transaction'] = Null;
        $amf->_bodys[0]->_value[1][0]['functionName'] = "WorldService.performAction";
        $amf->_bodys[0]->_value[1][0]['params'][0] = "list";
        $amf->_bodys[0]->_value[1][0]['params'][1] = array();
	    $amf->_bodys[0]->_value[1][0]['params'][1]['itemName'] = 'Market';
		$amf->_bodys[0]->_value[1][0]['params'][1]['id'] = $marketid;
		$amf->_bodys[0]->_value[1][0]['params'][1]['position'] = $marketpos;
		$amf->_bodys[0]->_value[1][0]['params'][1]['ch'] = $bot->ch($amf->_bodys[0]->_value[1][0]['params'][1]);
		
		$amf->_bodys[0]->_value[1][0]['params'][2][0] = array();
		//$amf->_bodys[0]->_value[1][0]['params'][2]['all'] = true;
		$amf->_bodys[0]->_value[1][0]['params'][2][0]['hostId'] = $neighid;
		$amf->_bodys[0]->_value[1][0]['params'][2][0]['ch'] = $bot->ch($amf->_bodys[0]->_value[1][0]['params'][2][0]);
		
        $serializer = new AMFSerializer();
        $result = $serializer->serialize($amf);
        return $bot->SendRequest($result);
    } 
	
	
?>
<?php

class UnitsPlugin {
	var $ld;
	var $xmlsOb;
	var $units;
	var $wants;
	var $CDATA;

	function UnitsPlugin()
	{
		$this->ld = new LocalData();
		$this->xmlsOb = new xmlsOb();
		$this->xmlsOb->GenerateData();
		$this->LoadCDATA();
	}

	// ============================================================================
	function LoadCDATA() // Added by pjhkaka
	{
		$CDATA = explode("\n",$this->xmlsOb->gsXML->assetIndex[0]);
		for($i=0;$i<count($CDATA);$i++)
		{
			$tmp = explode(':',$CDATA[$i]);
			$url = $tmp[1];
			$hash = $tmp[0];
			$tmp2 = explode('/',$tmp[1]);
			$flag = $tmp2[count($tmp2)-1];
			$this->CDATA[$flag]['hash'] = $hash;
			$this->CDATA[$flag]['url'] = $url;
		}
	}

	// ==========================================================================
	function GetForm()
	{
		global $imagePath;
		$imagePath = substr($_SERVER["PHP_SELF"], 0, strpos($_SERVER["PHP_SELF"], "/"));
		
		foreach ($this->xmlsOb->gsXML->items->item as $obj){
			if( $obj['type'] == 'Buildable' &&
				($obj['subtype'] == 'air' || $obj['subtype'] == 'army' || $obj['subtype'] == 'navy')) {
				$code = (string)$obj['code'];
				$tempunit['code'] = $code; // $key
				$tempunit['name'] = $obj['name'];
				$tempunit['ingamename'] = $this->xmlsOb->GetFnamefromCode($code);
				$tempunit['have'] = 0;
				
				foreach($obj->image as $img) {
					if ($img['name'] == "icon") {
						$tmptxt = $img['url'];
						$tmptxt2 = explode('/',$tmptxt);
						$url = $tmptxt2[count($tmptxt2)-1];
						$tempunit['url'] = $url;
						break;
					}
				}
				$this->units[$code] = $tempunit;
			}
		}
		
		$inventory = $this->ld->GetSelect('SELECT * FROM Inventory');
		foreach ($inventory as $have){
			$key = $have['Item'];
			if( $this->units[$key]['name'] != ''){
				$this->units[$key]['have'] = $have['Number'];
			}
		}
		
		$tmp = (array)$this->ld->GetPlSettings('Units');
		$this->wants = (array)$tmp['wants'];
		foreach($this->units as $key => $unit){
			if ( $this->wants[$key] == '' ){
				$this->wants[$key] = 0;
			}
		}
		
		if($tmp['produce'] ) {$checked = "checked";} else {$checked = "";}

		$text = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
			<html xmlns="http://www.w3.org/1999/xhtml" lang="ru">
    		<head>
        	<title>Making Units</title>
        	<script src="..\..\codebase-php\jquery-1.4.2.min.js"></script>
        	<script src="..\..\codebase-php\jquery.json-2.2.min.js"></script>
			<style> body { background-color: #CCCCFF;font-size: 10pt; font-family:Tahoma;}
			#Item { border:1px solid black; color:black; background-color:#f0f0f0; width:150px; height:165px; text-align:center; float:left;} maint{ border-style: solid;} </style>
		';
		
		$text .= '
			<script>
			
			//==============================================================
			window.reload = function(){
				var l=window.location.toString();
				var indx=l.indexOf(\'?\');
				window.location=l.slice(0, indx)+"?action=refresh&tmp="+Math.random();
			}
			//==============================================================
			$(document).ready(function(){ // Start document ready
				 window.settings=eval(' . json_encode($this->ld->GetPlSettings('Units')) . ');
			
				//==============================================================
				$("#btn_save").click(function(){
					var req=new Object();
					var wants = new Object();
					$(":checkbox").each(function(){ var par=$(this).attr("id");  req[par]=$(this).attr("checked"); });
		';
		
		foreach ($this->units as $key => $unit){
			$text .= '
					wants["'.$key.'"]=$("#'.$key.'").val();';
		}
		
		$text .= '
					req["wants"] = wants;
					data=$.toJSON(req);
					var l=window.location.toString();
					var indx=l.indexOf(\'?\');
					var nurl=l.slice(0, indx)+"?action=save&tmp="+Math.random();
					$.post(nurl, data);

					return false;
				});
			});
			</script>
		';
		
		$text .= '
			</head>
			<body>
			<form name="myform" >
			<div class="zag" height="35"><font size="6" color="blue">Build Locked Units</font><br><hr></div>
		
			<div>With this plugin, you can build locked units. Ofcourse this will require coins & ores.<br></div><br>
			<b><font color="blue" size="2">You have the following:</font></b>
			';
		$text .= '
			<br>
			<div> <input id="produce" type="checkbox" '.$checked.'/><font style="font-weight: bold; color: rgb(102, 0, 0);" color="green" size="3">Start producing units!!!</font><br />
			<hr>';
		
		foreach ($this->units as $key => $unit){
			$text .= '
			<div id=Item>
				<img src="http://empire.static.zgncdn.com/assets/hashed/'.$this->CDATA[$unit['url']]['hash'].'.png" align="middle" width="96" height="96">
				<br>
				'.$unit['ingamename'].'
				<br>
				Have : '.$unit['have'].'
				<br>
				Want? <input maxlength="3" size="4" id="'.$key.'" name="'.$key.'" value="'.$this->wants[$key].'" style="width:40px;" onPropertyChange="">
			</div>';
		}
		
		$text .= '
			 <hr>

            <div width="100%" align="center">
			<br><br>
			<button id="btn_save" style="color:black;background-color:#f0f0f0;border-width:2px;border-style:solid; ">&nbsp; Save settings&nbsp;</button>
            </div>
			</form>
			</body>
		</html>';

		echo $text;
	} 
};
?>
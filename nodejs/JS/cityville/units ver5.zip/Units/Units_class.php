<?php

class UnitsPlugin {
	var $ld;
	var $xmlsOb;

	function UnitsPlugin()
	{
		$this->ld = new LocalData();
		$this->xmlsOb = new xmlsOb();
	}
	
	// ==========================================================================
	function Save($postdata){	// Added by pjhkaka
		$data = $this->ld->GetPlSettings("Units");
		$units = (array)$data->units;
		$cycles = (array)$postdata->cycles;
		$limits = (array)$postdata->limits;
		foreach ($units as $key => $unit){
			$units[$key]['limit'] = (int)$limits[$key];
			$units[$key]['cycle'] = (int)$cycles[$key];
		}
		$savedata->produce = $postdata->produce;
		$savedata->units = $units;
		$this->ld->SavePlSettings('Units', $savedata);
	}

	// ==========================================================================
	function GetForm()
	{
		global $imagePath;
		$imagePath = substr($_SERVER["PHP_SELF"], 0, strpos($_SERVER["PHP_SELF"], "/"));
		
		$data = loadUnits($this);
		$units = (array)$data->units;
		
		if($data->produce) {$checked = "checked";} else {$checked = "";}

		$text = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
			<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
    		<head>
			<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        	<title>Making Units</title>
			<link rel=stylesheet type="text/css" href="helpers/plugin.css">
        	<script src="..\..\codebase-php\jquery-1.4.2.min.js"></script>
        	<script src="..\..\codebase-php\jquery.json-2.2.min.js"></script>
			<script>
			
			//==============================================================
			window.reload = function(){
				var l=window.location.toString();
				var indx=l.indexOf(\'?\');
				window.location=l.slice(0, indx)+"?action=refresh&tmp="+Math.random();
			}
			//==============================================================
			$(document).ready(function(){ // Start document ready
				//window.settings=eval('/* . json_encode($this->ld->GetPlSettings('Units'))*/ . ');
			
				//==============================================================
				$("#btn_save").click(function(){
					var req=new Object();
					var cycles = new Object();
					var limits = new Object();
					$(":checkbox").each(function(){ var par=$(this).attr("id");  req[par]=$(this).attr("checked"); });
		';
		
		foreach ($units as $key => $unit){
			$text .= '
					cycles["'.$key.'"]=$("#'.$key.'_cycle").val();
					limits["'.$key.'"]=$("#'.$key.'_limit").val();';
		}
		
		$text .= '
					req["cycles"] = cycles;
					req["limits"] = limits;
					data=$.toJSON(req);
					var l=window.location.toString();
					var indx=l.indexOf(\'?\');
					var nurl=l.slice(0, indx)+"?action=save&tmp="+Math.random();
					$.post(nurl, data);

					return false;
				});
			});
			</script>
			</head>
			<body>
			<form name="myform" >
			<div class="zag" height="35"><font size="6" color="blue">Build Locked Units</font><br><hr></div>
		
			<div>With this plugin, you can build locked units. Ofcourse this will require coins & ores.<br></div><br><br>
			<table><tr><td>
			<img class="icon" src="'.$imagePath.'Plugins/Units/helpers/inventory.png"> : Units in Inventory
			</td><td>
			<img class="icon" src="'.$imagePath.'Plugins/Units/helpers/total.png"> : Total Units
			</td></tr><tr><td>
			<img class="icon" src="'.$imagePath.'Plugins/Units/helpers/world.png"> : Units on Map
			</td><td>
			<img class="icon" src="'.$imagePath.'Plugins/Units/helpers/limit.png"> : limit of Units. zero is no limit
			</td></tr><tr><td>
			<img class="icon" src="'.$imagePath.'Plugins/Units/helpers/contracted.png"> : Contracted Units
			</td><td>
			<img class="icon" src="'.$imagePath.'Plugins/Units/helpers/cycle.png"> : How many units in 1 cycle?
			</td></tr></table>
			<br>
			<b><font color="blue" size="2">You have the following:</font></b>
			<br>
			<div> <input id="produce" type="checkbox" '.$checked.'/><font style="font-weight: bold; color: rgb(102, 0, 0);" color="green" size="3">Start producing units!!!</font><br />
			<hr>';
		
		foreach ($units as $key => $unit){
			if ($unit['url'] == '') $unit['url'] = $imagePath.'Plugins/Units/helpers/'.$key.'.png';
			else $unit['url'] = 'http://empire.static.zgncdn.com/assets/hashed/'.$unit['url'].'.png';
			$total = $unit['inventory']+$unit['world']+$unit['contracted'];
			$text .= '
			<div id=Item>
				<img class="pic" src="'.$unit['url'].'">
				<br>
				'.$unit['ingamename'].'
				<br>
				<input maxlength="3" size="1" value="'.$unit['inventory'].'" onPropertyChange="" readonly="readonly">
				<img class="icon" src="'.$imagePath.'Plugins/Units/helpers/inventory.png">
				<img class="icon" src="'.$imagePath.'Plugins/Units/helpers/total.png">
				<input class="total" maxlength="3" size="1" value="'.$total.'" onPropertyChange="" readonly="readonly" align="middle">
				<br>
				<input maxlength="3" size="1" value="'.$unit['world'].'" onPropertyChange="" readonly="readonly" align="middle">
				<img class="icon" src="'.$imagePath.'Plugins/Units/helpers/world.png">
				<img class="icon" src="'.$imagePath.'Plugins/Units/helpers/limit.png">
				<input class="limit" maxlength="3" size="1" id="'.$key.'_limit" value="'.$unit['limit'].'" onPropertyChange="">
				<br>
				<input maxlength="3" size="1" value="'.$unit['contracted'].'" onPropertyChange="" readonly="readonly" align="middle">
				<img class="icon" src="'.$imagePath.'Plugins/Units/helpers/contracted.png">
				<img class="icon" src="'.$imagePath.'Plugins/Units/helpers/cycle.png">
				<input class="cycle" maxlength="3" size="1" id="'.$key.'_cycle" value="'.$unit['cycle'].'" onPropertyChange="">
			</div>';
		}
		
		$text .= '
			 <hr>

            <div width="100%" align="center">
			<br><br>
			<button id="btn_save" style="color:black;background-color:#f0f0f0;border-width:2px;border-style:solid; ">&nbsp; Save settings&nbsp;</button>
            </div>
			</form>
			</body>
		</html>';

		echo $text;
	} 
};

// ============================================================================
function loadUnits($bot) { // load units. Added by pjhkaka
	$data = $bot->ld->GetPlSettings("Units");
	$cdata = LoadCDATA($bot);
	
	$units = array();
	$fakeunit = array('code'=>'fake', 'name'=>'fake', 'ingamename'=>'Fake Unit', 'special'=>0, 'duration'=>1, 'inventory'=>0, 'world'=>0, 'contracted'=>0, 'limit'=>0, 'cycle'=>0, 'count'=>0, 'url'=>'');
	$units['fake'] = $fakeunit;
	foreach ($bot->xmlsOb->gsXML->items->item as $obj){
		if( $obj['type'] == 'Buildable' &&
			($obj['subtype'] == 'air' || $obj['subtype'] == 'army' || $obj['subtype'] == 'navy')) {
			$code = (string)$obj['code'];
			$tempunit['code'] = (string)$code; // $key code
			$tempunit['name'] = (string)$obj['name'];
			$tempunit['ingamename'] = (string)$bot->xmlsOb->GetFnamefromCode($code);
			$tempunit['special'] = (int)isSpecial($obj);
			$tempunit['duration'] = (int)getDuration($obj->referenceValues); // maturing duration of unit
			$tempunit['inventory'] = 0; // units you have in inventory
			$tempunit['world'] = 0; // units you have on world
			$tempunit['contracted'] = 0; // units you had contracted
			$tempunit['limit'] = 0; // limitation of units
			$tempunit['cycle'] = 0; // units puchased in 1 cycle
			$tempunit['count'] = 0; // calculated number after considering inventory, limit, cycle

			foreach($obj->image as $img) { // hashed image path
				if ($img['name'] == "icon") {
					$tmptxt = $img['url'];
					$tmptxt2 = explode('/',$tmptxt);
					$url = $tmptxt2[count($tmptxt2)-1];
					$tempunit['url'] = (string)$cdata[$url]['hash'];
					break;
				}
			}
			$units[$code] = (array)$tempunit;
		}
	}
	
	uasort($units, "cmpduration");
	
	// ==================================================================   different with hooks.php
	$tempunits = (array)$data->units;
	foreach ($tempunits as $key => $tempunit){
		if ($units[$key]['name'] != ''){
			$units[$key]['cycle'] = (int)$tempunit['cycle'];
			$units[$key]['limit'] = (int)$tempunit['limit'];
			$units[$key]['inventory'] = (int)$tempunit['inventory'];
			$units[$key]['world'] = (int)$tempunit['world'];
			$units[$key]['contracted'] = (int)$tempunit['contracted'];
		}
	}
	// ==================================================================   end different
	
	$data->units = $units;
	
	return $data;
}

// ============================================================================
function LoadCDATA($bot) // load hash pic data, Added by pjhkaka
{
	$cdata = array();
	$hashes = explode("\n",$bot->xmlsOb->gsXML->assetIndex[0]);
	for($i=0;$i<count($hashes);$i++)
	{
		$tmp = explode(':',$hashes[$i]);
		$url = $tmp[1];
		$hash = $tmp[0];
		$tmp2 = explode('/',$tmp[1]);
		$flag = $tmp2[count($tmp2)-1];
		$cdata[$flag]['hash'] = $hash;
		$cdata[$flag]['url'] = $url;
	}
	return $cdata;
}

// ==============================================================================
function isspecial($obj){ // check whether special unit or not, Added by pjhkaka
	if ( $obj->requiredDate['start'] != '') return 1;
	if ( $obj['buyable'] == 'false' || $obj['zpoints'] == 'true') return 2;
	if ( $obj->requiredQuest != '' ) return 3;
	return 4;
}

// ==============================================================================
function cmpduration($a, $b){ // compare units by specialty/maturing duration, Added by pjhkaka
	if ($a['special'] == $b['special']) {
		if ($a['duration'] == $b['duration']) return 0;
		else return ($a['duration'] < $b['duration']) ? -1 : 1;
	} else return ($a['special'] < $b['special']) ? -1 : 1;
}

// ==============================================================================
function getDuration($referenceValues){ // get unit's maturing duration, Added by pjhkaka
	foreach ($referenceValues->define as $key => $value){
		if ( $value['name'] == "\$MaturingDuration"){
			$t_dr = (string)$value['value'];
			$s_dr = strlen($t_dr)-1;
			$i_dr = substr($t_dr,0,$s_dr);
			switch ($t_dr[$s_dr]){
				case 's': return $i_dr;
				case 'm': return 60 * $i_dr;
				case 'h': return 60 * 60 * $i_dr;
				case 'd': return 60 * 60 * 24 * $i_dr;
			}
		}
	}
	return 0;
}
?>
<?php

include('codebase-php\bot_api.php');
include('codebase-php\Utils.php');
include('codebase-php\LocalDataClass.php');
include('codebase-php\BotClass.php');
include('codebase-php\GetSettingsFromXml.php');

set_include_path(get_include_path() . PATH_SEPARATOR . "codebase-php");
$bot = new Bot();

AutoStart($argv);

include('Plugins\Units\Units_class.php');

$tp = new UnitsPlugin();
if (isset($getP['action'])) {
	if ($getP['action'] == 'refresh') {
		$tp->ld->userId = $CurrentUserId;
		$tp->ld->EasyConnect();
		$tp->GetForm();
	} 
	if ($getP['action'] == 'save') {
		$tp->ld->userId = $CurrentUserId;
		$tp->ld->EasyConnect();
		$tp->Save($postdata);
	} 
} 

?>
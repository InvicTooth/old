<?php
function Produce_Units($bot)
{
	if ($bot->firstrun) {
		return;
	}
	$bot->SendMsg('Produce units initializing...');
	$bot->SendMsg('');
	$bot->ReloadConfig();
	
	$data = loadUnits($bot);
	$units = (array)$data->units;
	$flag = (int)$data->flag;
	
	// save data into DB
	$savedata->produce = $data->produce;
	$savedata->units = $units;
	$bot->ld->SavePlSettings('Units', $savedata);
	
	if ((int)$data->produce != 1) {
		return;
	}
	if ($flag < 1){
		$bot->SendMsg('No units selected to produce.');
		$bot->SendMsg('');
		return;
	}

	$milB = array("Drydocks", "Barracks", "Hangar");
	$milBcnt1 = 0;
	$milBcnt2 = 0;
	foreach ($bot->fobjects as $obj) {
		if (in_array(strtok($obj['itemName'], ' '), $milB)){
			$milBcnt1++;
			if ($flag < 1) break;
/*
			if ($obj["state"] == 9) { // still in producing unit
				setState($bot,$obj,'cancel');
				if (isset($bot->error_msg)) {
					$bot->ReloadConfig();
					break;
				}
				$bot->SendMsg('Cancel '.$bot->xmlsOb->GetFname($obj["itemName"]).' ID : '.$obj['id']);
			}
*/
			if ($obj["state"] == 10) { // unit matured
				setState($bot,$obj,Null);
				if (isset($bot->error_msg)) {
					$bot->ReloadConfig();
					break;
				}
				$bot->SendMsg('Clearing out '.$bot->xmlsOb->GetFname($obj["itemName"]).' ID : '.$obj['id']);
				sleep(0.5);
			}
			if ($obj["state"] != 9){ // let's produce
				foreach($units as $key => $unit) {
					if ($units[$key]['count'] > 0) {
						setState($bot,$obj,$key);
						if (isset($bot->error_msg)) {
							$bot->ReloadConfig();
							break;
						}
						$bot->SendMsg('Success building '.$unit['ingamename'].' : '.$bot->xmlsOb->GetFname($obj["itemName"]). ' ID : ' . $obj['id']);
						$units[$key]['count']--;
						$flag--;
						$milBcnt2++;
						break;
					}
				}
			}
		}
	}

	$bot->SendMsg('');
	$bot->SendMsg('Done building... '.$milBcnt2.' / '.$milBcnt1);
}
$this->AddHook('produce_units', 'Produce_Units');


// ============================================================================
function loadUnits($bot) { // load units. Added by pjhkaka
	$data = $bot->ld->GetPlSettings("Units");
	$cdata = LoadCDATA($bot);
	
	$units = array();
	$fakeunit = array('code'=>'fake', 'name'=>'fake', 'ingamename'=>'Fake Unit', 'special'=>0, 'duration'=>1, 'inventory'=>0, 'world'=>0, 'contracted'=>0, 'limit'=>0, 'cycle'=>0, 'count'=>0, 'url'=>'');
	$units['fake'] = $fakeunit;
	foreach ($bot->xmlsOb->gsXML->items->item as $obj){
		if( $obj['type'] == 'Buildable' &&
			($obj['subtype'] == 'air' || $obj['subtype'] == 'army' || $obj['subtype'] == 'navy')) {
			$code = (string)$obj['code'];
			$tempunit['code'] = (string)$code; // $key code
			$tempunit['name'] = (string)$obj['name'];
			$tempunit['ingamename'] = (string)$bot->xmlsOb->GetFnamefromCode($code);
			$tempunit['special'] = (int)isSpecial($obj);
			$tempunit['duration'] = (int)getDuration($obj->referenceValues); // maturing duration of unit
			$tempunit['inventory'] = 0; // units you have in inventory
			$tempunit['world'] = 0; // units you have on world
			$tempunit['contracted'] = 0; // units you had contracted
			$tempunit['limit'] = 0; // limitation of units
			$tempunit['cycle'] = 0; // units puchased in 1 cycle
			$tempunit['count'] = 0; // calculated number after considering inventory, limit, cycle

			foreach($obj->image as $img) { // hashed image path
				if ($img['name'] == "icon") {
					$tmptxt = $img['url'];
					$tmptxt2 = explode('/',$tmptxt);
					$url = $tmptxt2[count($tmptxt2)-1];
					$tempunit['url'] = (string)$cdata[$url]['hash'];
					break;
				}
			}
			$units[$code] = (array)$tempunit;
		}
	}
	
	uasort($units, "cmpduration");
		
	// ==================================================================   different with Units_class.php
	$tempunits = (array)$data->units;
	foreach ($tempunits as $key => $tempunit){
		if ($units[$key]['name'] != ''){
			$units[$key]['cycle'] = (int)$tempunit['cycle'];
			$units[$key]['limit'] = (int)$tempunit['limit'];
		}
	}
	
	foreach ($bot->inventory as $key => $item){
		if( $units[$key]['name'] != '') $units[$key]['inventory'] = (int)$item;
	}
	
	$milB = array("Drydocks", "Barracks", "Hangar");
	foreach ($bot->fobjects as $obj){
		$key = (string)$bot->xmlsOb->GetItemCode($obj['itemName']);
		if ($units[$key]['name'] != '')
			$units[$key]['world']++;
		else if (in_array(strtok($obj['itemName'], ' '), $milB) && $units[$obj['referenceItem']]['name'] != '')
			$units[$obj['referenceItem']]['contracted']++;
	}
	
	$flag = 0;
	foreach($units as $key => $unit) {
		$limit = $unit['limit'];
		$cycle = $unit['cycle'];
		$vacant = $limit - $unit['inventory'] - $unit['world'] - $unit['contracted'];		
		if ($cycle == 0 || ($limit > 0 && $vacant < 1)) continue;
		else if ($limit == 0) $units[$key]['count'] = $cycle;
		else $units[$key]['count'] = min($vacant, $cycle);
		$flag += $units[$key]['count'];
//		$bot->sendMsg($key.' '.$unit['ingamename'].' '.$unit['duration'].' '.$units[$key]['count']);
	}
	$data->flag = $flag;
	// ==================================================================   end different		
	$data->units = $units;
	return $data;
}


// ============================================================================
function LoadCDATA($bot) // load hash pic data, Added by pjhkaka
{
	$cdata = array();
	$hashes = explode("\n",$bot->xmlsOb->gsXML->assetIndex[0]);
	for($i=0;$i<count($hashes);$i++)
	{
		$tmp = explode(':',$hashes[$i]);
		$url = $tmp[1];
		$hash = $tmp[0];
		$tmp2 = explode('/',$tmp[1]);
		$flag = $tmp2[count($tmp2)-1];
		$cdata[$flag]['hash'] = $hash;
		$cdata[$flag]['url'] = $url;
	}
	return $cdata;
}

// ==============================================================================
function isspecial($obj){ // check whether special unit or not, Added by pjhkaka
	if ( $obj->requiredDate['start'] != '') return 1;
	if ( $obj['buyable'] == 'false' || $obj['zpoints'] == 'true') return 2;
	if ( $obj->requiredQuest != '' ) return 3;
	return 4;
}

// ==============================================================================
function cmpduration($a, $b){ // compare units by specialty/maturing duration, Added by pjhkaka
	if ($a['special'] == $b['special']) {
		if ($a['duration'] == $b['duration']) return 0;
		else return ($a['duration'] < $b['duration']) ? -1 : 1;
	} else return ($a['special'] < $b['special']) ? -1 : 1;
}

// ==============================================================================
function getDuration($referenceValues){ // get unit's maturing duration, Added by pjhkaka
	foreach ($referenceValues->define as $key => $value){
		if ( $value['name'] == "\$MaturingDuration"){
			$t_dr = (string)$value['value'];
			$s_dr = strlen($t_dr)-1;
			$i_dr = substr($t_dr,0,$s_dr);
			switch ($t_dr[$s_dr]){
				case 's': return $i_dr;
				case 'm': return 60 * $i_dr;
				case 'h': return 60 * 60 * $i_dr;
				case 'd': return 60 * 60 * 24 * $i_dr;
			}
		}
	}
	return 0;
}

// ==============================================================================
function setState($bot,$obj,$itemcode) // produce locked units
{
    unset($bot->error_msg);
    $amf = new AMFObject("");
    $amf->_bodys[0] = new MessageBody();
    $amf->_bodys[0]->_value[0] = $bot->GetAmfHeader();

    $amf->_bodys[0]->targetURI = 'BaseService.dispatchBatch';
    $amf->_bodys[0]->responseURI = '';
    $amf->_bodys[0]->_value[2] = 0;
	
	$amf->_bodys[0]->_value[1][0]['sequence'] = $bot->GetSequense();
    $amf->_bodys[0]->_value[1][0]['functionName'] = "WorldService.performAction";
    $amf->_bodys[0]->_value[1][0]['params'][0] = "setState";
	if ($itemcode == 'fake'){
		$amf->_bodys[0]->_value[1][0]['params'][1] = array();
		$amf->_bodys[0]->_value[1][0]['params'][1]['id'] = $obj['id'];
		$amf->_bodys[0]->_value[1][0]['params'][1]['position'] = $obj['position'];
		$amf->_bodys[0]->_value[1][0]['params'][1]['itemName'] = $obj['itemName'];	
	} else if ($itemcode == 'cancel') {
		$amf->_bodys[0]->_value[1][0]['params'][1] = $obj;
		$amf->_bodys[0]->_value[1][0]['params'][2][0]['referenceItem'] = "Null";
		$amf->_bodys[0]->_value[1][0]['params'][2][0]['cancel'] = "true";
	} else {
		$amf->_bodys[0]->_value[1][0]['params'][1] = $obj;
		$amf->_bodys[0]->_value[1][0]['params'][2][0]['referenceItem'] = $itemcode;
	}
	
	$amf->_bodys[0]->_value[1][0]['params'][1]['ch'] = $bot->ch($amf->_bodys[0]->_value[1][0]['params'][1]);
	$amf->_bodys[0]->_value[1][0]['params'][2][0]['ch'] = $bot->ch($amf->_bodys[0]->_value[1][0]['params'][2][0]);
	
	if ($obj['state'] == 10 && $obj['referenceItem'] == '') {
		$bot->dooberItems += 1;
		sleep(2);
	}
	
	$serializer = new AMFSerializer();
	$result = $serializer->serialize($amf);
	return $bot->SendRequest($result);
	}


/*
// secert function.
function GetImages($bot)
{
	//GetImages($bot);
//	return;
	$urlhead = 'http://empire.static.zgncdn.com/';
	$XML = simplexml_load_file('tmp_dir\asdf.xml');
	foreach($XML as $key => $value){
		$key = trim($value->Key);
		//$bot->sendMsg($key);
		$url = $urlhead.$key;
		$tmp = explode('/',$key);
		$pic = $tmp[count($tmp)-1];
		$tmp2 = explode('.',$pic);
		if ( $tmp2[1] == 'png' && file_exists('tmp_dir\\'.$pic) == false) $bot->DownloadFile($urlhead.$key, $pic);
	}
}
*/
?>
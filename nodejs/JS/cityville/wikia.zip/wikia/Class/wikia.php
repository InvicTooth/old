<?php
class wikia
{
	var $XML;
	var $items; //	all item objects
//	var $RMT;	//	Random Modifier Tables
	var $CDATA;
	var $strings;
	
	var $item;	//	Costom Item data
	var $menu;	//	Costom Menu
	var $RT;	//	Costom Random Modifier Table
	
	var $Form;	//	Show Form Mode
	var $bug;	//	Show Debug Mode
	var $IMAGE; //	Show Image Mode
	function Init()
	{
		$this->debug('Init() - start');
		$state = $this->findfile('gameSettings.xml');
		if ($state)
		{
			$this->LoadXML($state);
			$this->Proc();
			$this->showMneu();
			$this->showItem();
		}
		$this->debug('Init() - end');
	}
	function LoadXML($path)
	{
		$this->debug('Load XML Object - start');
		$this->XML = simplexml_load_file($path,'SimpleXMLElement',LIBXML_NOCDATA);
		$this->items = $this->XML->items;
		$this->CDATA = $this->XML->assetIndex[0];
		$this->LoadCDATA();
		
		$SXML = simplexml_load_file($this->findfile('en_US.xml'),'SimpleXMLElement',LIBXML_NOCDATA);
		foreach ($SXML->pkg as $pkg) {
			foreach ($pkg->string as $string) {
				$key = (string)$string['key'];
				if (strpos($key, '_menuName') !== false) {
					$key = substr($key, 0, strpos($key, '_menuName'));
					$this->strings[$key] = (string)$string->original;
				} 
			} 
		} 
		
		$this->debug('Load XML Object - end');
	}
	function LoadCDATA()
	{
		$this->debug('LoadCDATA() - start');
		$CDATA = explode("\n",$this->CDATA);
		unset($this->CDATA);
		for($i=0;$i<count($CDATA);$i++)
		{
			$tmp = explode(':',$CDATA[$i]);
			$url = $tmp[1];
			$hash = $tmp[0];
			$tmp2 = explode('/',$tmp[1]);
			$flag = $tmp2[count($tmp2)-1];
			$this->CDATA[$flag]['hash'] = $hash;
			$this->CDATA[$flag]['url'] = $url;
		}
		$this->debug('LoadCDATA() - end');
	}
	function Proc()
	{
		$this->debug('Load Menu & Item Object - start');
		
		foreach($this->items->item as $item)
		{
			$name = strval($item->attributes()->name);
			//	Load Attributes value
			foreach($item->attributes() as $attr => $value) 
			{
				$s_attr = strval($attr);
				$this->item[$name]->attr->$s_attr = strval($value);
			}
			
			//	Load Etc tag value
			foreach($item as $tag => $value)
			{
				$s_tag = strval($tag);
				$this->item[$name]->tag->$s_tag = $value;
			}
			
			//	Load Image			
			foreach($item->image as $img)	 //	Use bad method, edit the method later
			{
				$img_Name = strval($img->attributes()->name);
				if ($img_Name == "icon")
				{
					$url = strval($img->attributes()->url);
					$this->item[$name]->url = $url;
					break;
				}
			}
			
			$type = $this->item[$name]->attr->type.'<br>'.$this->item[$name]->attr->subtype;
			
			//	Load Menu
			if (!empty($type))	$this->menu->all[$type]->key = $type;
			else
			{
				$this->item[$name]->type = 'map';
				$this->menu->all['map']->key = 'map';
			}
		}
		$this->debug('Load Menu & Item Object - end');			
	}
	function showMneu($mode='all')
	{
		$this->debug('Show Menu - Start');
		
		$this->PushForm('<div id="menu">');
		foreach($this->menu->$mode as $type => $key) $this->PushForm(sprintf('<span id="link" class="btnOFF" onclick="showdiv(this)">%s</span>',$type));
		$this->PushForm('</div>');
		
		$this->debug('Show Menu - end');
	}
	function showItem($mode='all')
	{
		foreach($this->menu->$mode as $type => $key)
		{
			$this->PushForm('<div id="data" style="display:none;">');
			foreach($this->item as $name => $value)
			{
				if ($type == $value->attr->type.'<br>'.$value->attr->subtype)
				{
//					$path = $this->findfile($value->url);
					$tmp = $value->url;
					$tmp2 = explode('/',$tmp);
					$flag = $tmp2[count($tmp2)-1];
					$path = 'http://empire.static.zgncdn.com/assets/hashed/'.$this->CDATA[$flag]['hash'].'.png';
//					if ($this->CDATA[$flag]['hash'] != '')
					if(true)
					{
						$this->PushForm('<div id="%s" class="body">',$value->name);
						$this->PushForm(sprintf('<span class="Pic"><img src="%s" /></span>',$path));
						$this->PushForm('<span class="Inf">');
						$this->showAttr($value->attr);
						$this->PushForm('</span>');
						$this->showTag($value);
						$this->PushForm('</div>');
					}
				}
			}
			$this->PushForm('</div>');
		}
	}
	function showAttr($obj)
	{
		if ($this->strings[$obj->name] != '') $this->PushForm(sprintf('Ingame Name: %s',$this->strings[$obj->name]).'<br/>');
		foreach($obj as $attr => $value) {
			$this->PushForm($attr.'	: '.$value.'<br/>');
		}
	}
	function showTag($obj)
	{
		$this->PushForm('<span class="inf"><b>Single tags</b><br>');
		foreach ((array)$obj->tag as $tag => $value) {
			if ($value != '') $this->PushForm($tag.' : '.$value.'<br>');
		}
		$this->PushForm('</span>');
		foreach ((array)$obj->tag as $tag => $value) {
			if ($tag == 'image' ||
				$tag == 'referenceImage' ||
				$tag == 'additionalImage' ||
				$tag == 'contractImages' ||
				$tag == 'loc') continue;
			if ($value == '') {
				$this->PushForm('<span class="inf"><b>'.$tag.'</b><br>');
				$this->printtag($value, '');
				$this->PushForm('</span>');
			}
		}
	}
	function printtag($tag, $text, $flag = false){
		$text .= '<b style="color:white">_</b>';
		foreach ($tag->attributes() as $key => $val){
			if ($flag && ($key == 'name' || $key == 'value')) continue;
			$this->PushForm($text.$key.' : '.$val.'<br>');
		}
		foreach ($tag as $key2 => $val2) {
			if ( $key2 == 'define' ) {
				$this->PushForm($text.$val2['name'].' : '.$val2['value'].'<br>');
				$this->printtag($val2, $text, true);
			} else {
				$this->PushForm($text.'<b>'.$key2.'</b><br>');
				$this->printtag($val2, $text);
			}
		}
	}
	function findfile($path)
	{
		$flag = false;
		$url = dirname(dirname(dirname(dirname(__FILE__)))).'\\';
		$PATH = array($url,$url.'tmp_dir\\','http://empire.static.zgncdn.com/assets/hashed/');
		$F_info = explode('.',$path);
		$last = count($F_info)-1;
		if (!empty($F_info[$last]))
		{
			for($i = 0;$i< count($PATH) ; $i++)
			{
				if ($i == count($PATH)-1)
				{
					//	remote location
					$Full_Path = $PATH[$i] . $this->CDATA[$path] . '.' . $F_info[$last];
					if ($this->CDATA[$path]!="")	$flag = $Full_Path;
				}
				else
				{
					//	local location
					$Full_Path = $PATH[$i].$path;
					if (file_exists($Full_Path))
						$flag = $Full_Path;
				}
				if ($flag)	break;
			}
		}
		return $flag;
	}
	function show($mode='')
	{
		$body = 0;
		$body = $this->Form;
		return $body;
	}
	function debug($msg)
	{
		$this->bug .= $msg.'<br/>';
	}
	function PushForm($txt)
	{
		$this->Form .= $txt;
	}
	function showImg($msg,$mode)
	{
		switch($mode)
		{
			case 'txt':
				$this->IMAGE .= $msg;
				break;
			case 'img':
				$this->IMAGE .= sprintf('<span class="Pic"><img src="%s" /></span>',$msg);
				break;
		}
		
	}
}
?>